package com.hunain.generalstore

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245,247,250))
        }

        val header = TextView(this).apply {
            text = "Hunain General Store"
            textSize = 24f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(21,101,192))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 30, 24, 30)
        }
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18,18,18,24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        setContentView(root)
        showDashboard()
    }

    private fun showDashboard() {
        content.removeAllViews()
        addTitle("Dashboard")
        addCard("Today's Sales", "Rs. 0")
        addCard("Today's Profit", "Rs. 0")
        addCard("Low Stock", "0 items")
        addCard("Customer Udhaar", "Rs. 0")

        addButton("Products / Stock") { products() }
        addButton("Sales / Billing") { sales() }
        addButton("Customers / Udhaar") { customers() }
        addButton("Purchases / Suppliers") { purchases() }
        addButton("Expenses") { expenses() }
        addButton("Reports") { reports() }
    }

    private fun products() {
        content.removeAllViews(); addTitle("Products & Stock")
        addInput("Product name")
        addInput("Selling price")
        addInput("Purchase price")
        addInput("Quantity / Stock")
        addButton("Save Product") { toast("Product saved") }
        addButton("Back to Dashboard") { showDashboard() }
    }

    private fun sales() {
        content.removeAllViews(); addTitle("Sales / Billing")
        addInput("Product name or barcode")
        addInput("Quantity")
        addInput("Customer (optional)")
        addButton("Add to Bill") { toast("Added to bill") }
        addButton("Save Sale") { toast("Sale saved") }
        addButton("Back to Dashboard") { showDashboard() }
    }

    private fun customers() {
        content.removeAllViews(); addTitle("Customers / Udhaar")
        addInput("Customer name")
        addInput("Phone number")
        addInput("Udhaar amount")
        addButton("Save Customer") { toast("Customer saved") }
        addButton("Back to Dashboard") { showDashboard() }
    }

    private fun purchases() {
        content.removeAllViews(); addTitle("Purchases / Suppliers")
        addInput("Supplier name")
        addInput("Product")
        addInput("Purchase amount")
        addButton("Save Purchase") { toast("Purchase saved") }
        addButton("Back to Dashboard") { showDashboard() }
    }

    private fun expenses() {
        content.removeAllViews(); addTitle("Expenses")
        addInput("Expense title")
        addInput("Amount")
        addButton("Save Expense") { toast("Expense saved") }
        addButton("Back to Dashboard") { showDashboard() }
    }

    private fun reports() {
        content.removeAllViews(); addTitle("Reports")
        addCard("Daily Sales", "Rs. 0")
        addCard("Daily Expenses", "Rs. 0")
        addCard("Daily Profit", "Rs. 0")
        addCard("Total Udhaar", "Rs. 0")
        addButton("Back to Dashboard") { showDashboard() }
    }

    private fun addTitle(t: String) {
        content.addView(TextView(this).apply {
            text=t; textSize=22f; setTextColor(Color.rgb(30,30,30))
            setPadding(0,8,0,16)
        })
    }

    private fun addCard(title:String, value:String) {
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(20,18,20,18)
            setBackgroundColor(Color.WHITE)
        }
        box.addView(TextView(this).apply { text=title; textSize=15f })
        box.addView(TextView(this).apply { text=value; textSize=22f; setTextColor(Color.rgb(21,101,192)) })
        content.addView(box, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,12) })
    }

    private fun addInput(hint:String) {
        val e=EditText(this).apply { this.hint=hint; setSingleLine(true) }
        content.addView(e, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,8) })
    }

    private fun addButton(text:String, action:()->Unit) {
        val b=Button(this).apply { this.text=text; setOnClickListener { action() } }
        content.addView(b, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0,4,0,4) })
    }

    private fun toast(msg:String) = Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()
}
